package Ventanas;
import java.awt.Image;
import java.io.File;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import manejodestockyventas.Inventario;
/**
 * @author STHEPHAN ALEXANDER GARCIA MAROOQUIN
 * CARNET:200915522
 * IPC1 "A" VACACIONES 2019
 */
public class RegistrarInsumo extends javax.swing.JFrame {
    private Inventario inventario;
    private VentanaInicio ventana1;
    
    private Image img;
    private ImageIcon img2;
    private String dirImagen="";
    
    
    public RegistrarInsumo(Inventario inventario) {
        initComponents();
        this.setLocationRelativeTo(null);
        
        this.inventario= inventario;
        
    }
    
   public RegistrarInsumo(){
       this(new Inventario());

   } 
    
    @SuppressWarnings("unchecked")


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        imagen = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        minimo = new javax.swing.JTextField();
        nombre = new javax.swing.JTextField();
        cantidad = new javax.swing.JTextField();
        maximo = new javax.swing.JTextField();
        costo = new javax.swing.JTextField();
        descripcion = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        cancelarAddInsumo = new javax.swing.JButton();
        AceptarAddInsumo = new javax.swing.JButton();
        cargarInsumos = new javax.swing.JButton();
        cargarProductos = new javax.swing.JButton();
        cargarImagenInsumo = new javax.swing.JButton();

        jLabel5.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel5.setText("Cantidad tope:");

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setFocusTraversalPolicyProvider(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Nombre:");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Existencias:");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Cantidad minima:");
        jLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Cantidad tope:");
        jLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        imagen.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        imagen.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Costo:");
        jLabel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel9.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Descripción:");
        jLabel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        minimo.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        minimo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimoActionPerformed(evt);
            }
        });

        nombre.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreActionPerformed(evt);
            }
        });

        cantidad.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        cantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cantidadActionPerformed(evt);
            }
        });

        maximo.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        maximo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maximoActionPerformed(evt);
            }
        });

        costo.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        costo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                costoActionPerformed(evt);
            }
        });

        descripcion.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        descripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                descripcionActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 2, 48)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("REGISTRO DE INSUMOS");

        cancelarAddInsumo.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        cancelarAddInsumo.setText("Cancelar");
        cancelarAddInsumo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        cancelarAddInsumo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarAddInsumoActionPerformed(evt);
            }
        });

        AceptarAddInsumo.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        AceptarAddInsumo.setText("Aceptar");
        AceptarAddInsumo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        AceptarAddInsumo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AceptarAddInsumoActionPerformed(evt);
            }
        });

        cargarInsumos.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        cargarInsumos.setText("Cargar insumos");
        cargarInsumos.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        cargarInsumos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cargarInsumosActionPerformed(evt);
            }
        });

        cargarProductos.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        cargarProductos.setText("Cargar productos");
        cargarProductos.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        cargarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cargarProductosActionPerformed(evt);
            }
        });

        cargarImagenInsumo.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        cargarImagenInsumo.setText("Cargar imagen insumo");
        cargarImagenInsumo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        cargarImagenInsumo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cargarImagenInsumoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nombre)
                            .addComponent(minimo)
                            .addComponent(cantidad, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(maximo)
                            .addComponent(descripcion)
                            .addComponent(costo, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(cargarInsumos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cargarProductos, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                            .addComponent(cargarImagenInsumo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(34, 34, 34))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 584, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(cancelarAddInsumo, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(96, 96, 96))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(80, 80, 80)
                    .addComponent(AceptarAddInsumo, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(347, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(minimo, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(maximo, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(costo, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(cargarImagenInsumo, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cargarInsumos, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cargarProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(15, 15, 15)
                .addComponent(cancelarAddInsumo, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                .addGap(23, 23, 23))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(710, 710, 710)
                    .addComponent(AceptarAddInsumo, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addGap(23, 23, 23)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void minimoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_minimoActionPerformed
    private void nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombreActionPerformed
    private void cantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cantidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cantidadActionPerformed
    private void maximoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maximoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_maximoActionPerformed
    private void costoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_costoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_costoActionPerformed
    private void descripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_descripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_descripcionActionPerformed
    private void cancelarAddInsumoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarAddInsumoActionPerformed
        //BOTON CANCELAR
        int opcion=JOptionPane.showConfirmDialog(null,"¿Está seguro de desea cancelar la agregacion de este insumo al inventario?","Cancelación de insumo",2);
            if(opcion==JOptionPane.YES_OPTION){
                
                ventana1 = new VentanaInicio(inventario);
                ventana1.setVisible(true);            
                this.setVisible(false);

        }
        
    }//GEN-LAST:event_cancelarAddInsumoActionPerformed
    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        
        
    }//GEN-LAST:event_formWindowClosed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
    }//GEN-LAST:event_formWindowClosing

    private void AceptarAddInsumoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AceptarAddInsumoActionPerformed
        //Boton aceptar
        
        if(nombre.getText().isEmpty()||cantidad.getText().isEmpty()||minimo.getText().isEmpty()||maximo.getText().isEmpty()||
        costo.getText().isEmpty()||descripcion.getText().isEmpty()||dirImagen.equals("")){
        JOptionPane.showMessageDialog(null, "Rellene todos los campos, para agregar un insumo al inventario no debe en blanco ningun campo, tambien agregar imagen");
        }else{            
            try{//Declaracion de varibales de JTextFields rellenados
                int verInv = inventario.getTamArreglo();
                
                
                if(verInv==1){//inventario de insumos vacio
                    
                    int identificador=verInv;
                    String nombreLocalNuevo=nombre.getText();
                    int cantidadLocalNuevo=Integer.parseInt(cantidad.getText());
                    int minLocalNuevo=Integer.parseInt(minimo.getText());
                    int maxLocalNuevo=Integer.parseInt(maximo.getText());
                    double costoLocalNuevo=Double.parseDouble(costo.getText());
                    String descripcionLocalNuevo=descripcion.getText();
                    String archivoLocalNuevo=dirImagen;

                    if((cantidadLocalNuevo>0)&&(minLocalNuevo>0)&&(maxLocalNuevo>0)&&(costoLocalNuevo>0)){
                        if((cantidadLocalNuevo>minLocalNuevo)&&(cantidadLocalNuevo<maxLocalNuevo)){
                            int opcion=JOptionPane.showConfirmDialog(null, "Está seguro que desea agregar al inventario este insumo?","Confirmación de insumo agregado",2);

                            if(opcion==JOptionPane.YES_OPTION){

                                inventario=new Inventario(identificador,nombreLocalNuevo,cantidadLocalNuevo,minLocalNuevo,maxLocalNuevo,costoLocalNuevo, descripcionLocalNuevo,archivoLocalNuevo,verInv);
                                ventana1 = new VentanaInicio(inventario);
                                
                                ventana1.setVisible(true);            
                                this.setVisible(false);


                            }
                        }else{
                            JOptionPane.showMessageDialog(null,"los parametro numericos no coinciden en existencias, maximos y minimos");

                        }
                    }else{
                        JOptionPane.showMessageDialog(null, "Ingrese los datos numericos correctamente(NO negativos porfavor)");

                    }
                
                }else {//agregar un insumo cuando ya hay insumos agraegados al inventario
                    
                    int identificador=verInv;
                    String nombreLocalNuevo=nombre.getText();
                    int cantidadLocalNuevo=Integer.parseInt(cantidad.getText());
                    int minLocalNuevo=Integer.parseInt(minimo.getText());
                    int maxLocalNuevo=Integer.parseInt(maximo.getText());
                    double costoLocalNuevo=Double.parseDouble(costo.getText());
                    String descripcionLocalNuevo=descripcion.getText();
                    String archivoLocalNuevo=dirImagen;
                    
                    if((cantidadLocalNuevo>0)&&(minLocalNuevo>0)&&(maxLocalNuevo>0)&&(costoLocalNuevo>0)){
                        if((cantidadLocalNuevo>minLocalNuevo)&&(cantidadLocalNuevo<maxLocalNuevo)){
                            int opcion=JOptionPane.showConfirmDialog(null, "Está seguro que desea agregar al inventario este insumo?","Confirmación de insumo agregado",2);

                            if(opcion==JOptionPane.YES_OPTION){
                                
                                Inventario inventarioCopiado = new Inventario();
                                
                                inventarioCopiado=inventario;

                                inventario=new Inventario(identificador,nombreLocalNuevo,cantidadLocalNuevo,minLocalNuevo,maxLocalNuevo,costoLocalNuevo, descripcionLocalNuevo,archivoLocalNuevo,verInv,inventarioCopiado);
                                ventana1 = new VentanaInicio(inventario);
                                ventana1.setVisible(true);            
                                this.setVisible(false);


                            }//---------------------------------------
                        }else{
                            JOptionPane.showMessageDialog(null,"los parametro numericos no coinciden en existencias, maximos y minimos");

                        }
                    }else{
                        JOptionPane.showMessageDialog(null, "Ingrese los datos numericos correctamente(NO negativos porfavor)");

                    }
            
                }
                
                
                
            }catch(Exception e){
                JOptionPane.showMessageDialog(null,"Los datos proveidos no estan ingresados apropiadamente");
                System.out.println(e);
            }
        }
        
    }//GEN-LAST:event_AceptarAddInsumoActionPerformed
    
    private void cargarInsumosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cargarInsumosActionPerformed
                
        int opcion=JOptionPane.showConfirmDialog(null, "Está seguro que desea cargar inventario de insumos de forma masiva(Reset de Insumos)?","Confirmación de insumos agregado",2);

            if(opcion==JOptionPane.YES_OPTION){
                
                try{
                JFileChooser fileInsumos= new JFileChooser();
                FileNameExtensionFilter filtro = new FileNameExtensionFilter("*.XML","xml");
                fileInsumos.setFileFilter(filtro);
                int seleccion = fileInsumos.showOpenDialog(this);
                    
                    if (seleccion==JFileChooser.APPROVE_OPTION){
                        
                        File fichero = fileInsumos.getSelectedFile();
                        String direccionInsumo = (String) fichero.getAbsolutePath();
                        
                        inventario=new Inventario(inventario,direccionInsumo);
                        
                        ventana1 = new VentanaInicio(inventario);
                        ventana1.setVisible(true);            
                        this.setVisible(false);
                        
                    }
                    
                }catch(Exception e){
                    System.out.println(e);
                }

            }
        
    }//GEN-LAST:event_cargarInsumosActionPerformed

    private void cargarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cargarProductosActionPerformed
    
        int verInv = inventario.getTamArreglo();
        if(verInv>1){
            int opcion=JOptionPane.showConfirmDialog(null, "Está seguro que desea cargar inventario de productos de forma masiva(Reset de productos)?","Confirmación de productos agregado",2);

            if(opcion==JOptionPane.YES_OPTION){

                   try{
                   JFileChooser fileInsumos= new JFileChooser();
                   FileNameExtensionFilter filtro = new FileNameExtensionFilter("*.XML","xml");
                   fileInsumos.setFileFilter(filtro);
                   int seleccion = fileInsumos.showOpenDialog(this);

                       if (seleccion==JFileChooser.APPROVE_OPTION){

                           File fichero = fileInsumos.getSelectedFile();
                           String direccionproducto = (String) fichero.getAbsolutePath();

                           inventario=new Inventario(direccionproducto,inventario);
                           ventana1 = new VentanaInicio(inventario);
                           ventana1.setVisible(true);            
                           this.setVisible(false);

                       }

                   }catch(Exception e){
                       System.out.println(e);
                   }


               }
            }else{
            
                JOptionPane.showMessageDialog(null,"¡Cuidado!, debe ingresar insumos, para poder cargar los productos de insumos existentes ", "Advertencia de falta de insumos", 1);
        
            }
        
    }//GEN-LAST:event_cargarProductosActionPerformed

    private void cargarImagenInsumoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cargarImagenInsumoActionPerformed
        
    try{
        JFileChooser imagenSel = new JFileChooser();
            FileNameExtensionFilter imgFilter = new FileNameExtensionFilter("JPEG FILE","jpg","jpeg");
            imagenSel.setFileFilter(imgFilter);
            int selImg = imagenSel.showOpenDialog(this);
            
            if(selImg==JFileChooser.APPROVE_OPTION){
            File fileImg = imagenSel.getSelectedFile();
            dirImagen=fileImg.getAbsolutePath();
            
            img= new ImageIcon(dirImagen).getImage();
            img2=new ImageIcon(img.getScaledInstance(306, 210, Image.SCALE_SMOOTH));
            imagen.setIcon(img2);
            
            
            
            
            
            
            
            
            
            
            
            }
        }catch(Exception e){
            System.out.println(e);
        }    
    }//GEN-LAST:event_cargarImagenInsumoActionPerformed

    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistrarInsumo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistrarInsumo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistrarInsumo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistrarInsumo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistrarInsumo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AceptarAddInsumo;
    private javax.swing.JButton cancelarAddInsumo;
    private javax.swing.JTextField cantidad;
    private javax.swing.JButton cargarImagenInsumo;
    private javax.swing.JButton cargarInsumos;
    private javax.swing.JButton cargarProductos;
    private javax.swing.JTextField costo;
    private javax.swing.JTextField descripcion;
    private javax.swing.JLabel imagen;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField maximo;
    private javax.swing.JTextField minimo;
    private javax.swing.JTextField nombre;
    // End of variables declaration//GEN-END:variables
}
