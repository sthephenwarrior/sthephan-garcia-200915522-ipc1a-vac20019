package manejodestockyventas;

import java.util.ArrayList;

/**
 * @author STHEPHAN ALEXANDER GARCIA MAROOQUIN
 * CARNET:200915522
 * IPC1 "A" VACACIONES 2019
 */
public class Producto {
    
    private String nombre;
    private double precio;
    private String descripcion;
    
    private String cadenaInsumos;
    
    private String PathImage;
    private Insumo insumo[];
    
    
    public Producto(String nombrePr, double precioPr,String descripcionPr,String insumosPr,String pathImagePr){
        setNombre(nombrePr);
        setPrecio(precioPr);
        setDescripcion(descripcionPr);
        setCadenaInsumos(insumosPr);
        setPathImage(pathImagePr);
        
        setInsumoSplit(this.cadenaInsumos);
        
        
        
    }
    
    public Producto(){
        this("",0.0,"","","");
    }
    
    public void setInsumoSplit(String insuCadena){
        
        String cadena = insuCadena;
            ArrayList<Character> lista = new ArrayList<>();
            for(int i = 0; i< cadena.length(); i ++)
            {
                if(Character.isDigit(cadena.charAt(i)))
                    lista.add(cadena.charAt(i));

            }
            int lol = lista.size();
            
            
            
            insumo= new Insumo[lol];
            
            for(int i=0;i<lol;i++){
                
                insumo[i]=new Insumo(lista.get(i));
                //System.out.println(lista.get(i));
            }
            
            
         
        
    
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setCadenaInsumos(String cadenaInsumos) {
        this.cadenaInsumos = cadenaInsumos;
    }

    public void setPathImage(String PathImage) {
        this.PathImage = PathImage;
    }

    public void setInsumo(Insumo[] insumo) {
        this.insumo = insumo;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getCadenaInsumos() {
        return cadenaInsumos;
    }

    public String getPathImage() {
        return PathImage;
    }

    public Insumo[] getInsumo() {
        return insumo;
    }

    @Override
    public String toString() {
        
        
        return "Producto{" + "nombre=" + nombre + ", precio=" + precio + ", descripcion=" + descripcion + ", cadenaInsumos=" + cadenaInsumos + ", PathImage=" + PathImage + ", insumo=" + insumo + '}';
    }
    
    

    
    
    
}
