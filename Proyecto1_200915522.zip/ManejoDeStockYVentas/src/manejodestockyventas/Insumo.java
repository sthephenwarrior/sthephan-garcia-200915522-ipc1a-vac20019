package manejodestockyventas;
/**
 * @author STHEPHAN ALEXANDER GARCIA MAROOQUIN
 * CARNET:200915522
 * IPC1 "A" VACACIONES 2019
 */

public class Insumo {
    
    private int numIdentificadorInsumo;
    private String nombre;
    private int cantidad;
    private int max;
    private int min;
    private double costo;
    private String descp;
    private String imagen;
    
    
    
    public Insumo(int num,String nombre,int cantidad,int cantMin,int canMax,double costo,String descp, String imagen){
        setNumIdentificadorInsumo(num);
        setNombre(nombre);
        setCantidad(cantidad);
        setMin(cantMin);
        setMax(canMax);
        setCosto(costo);
        setDescp(descp);
        setImagen(imagen);
        
    }
    public Insumo(){
        this(0,"",0,0,0,0.0,"","");
        
    
    }
    
    public Insumo(int num){
        
        
        setNumIdentificadorInsumo(num);
    }
    

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
    
    public String getDescp() {
        return descp;
    }

    public void setDescp(String descp) {
        this.descp = descp;
    }

    public int getNumIdentificadorInsumo() {
        return numIdentificadorInsumo;
    }

    public void setNumIdentificadorInsumo(int numIdentificadorInsumo) {
        this.numIdentificadorInsumo = numIdentificadorInsumo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    @Override
    public String toString() {
        
        return "Insumo{" + "numIdentificadorInsumo=" + numIdentificadorInsumo + ", nombre=" + nombre + ", cantidad=" + cantidad + ", max=" + max + ", min=" + min + ", costo=" + costo + ", descp=" + descp + ", imagen=" + imagen + '}';
    }

    
}
