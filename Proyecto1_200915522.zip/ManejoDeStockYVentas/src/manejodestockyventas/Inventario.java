package manejodestockyventas;
/**
 * @author STHEPHAN ALEXANDER GARCIA MAROOQUIN
 * CARNET:200915522
 * IPC1 "A" VACACIONES 2019
 */
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
/**
* @author STHEPHAN ALEXANDER GARCIA MAROOQUIN
 * CARNET:200915522
 * IPC1 "A" VACACIONES 2019
 */
public class Inventario {
    
    //PARTE CAPITAL    
    private Double capital=0.00;
    
    //PARTE INSUMOS
    private Insumo insumos[];    
    private Insumo insumosInventarioAgregado[];
    
    private Insumo insumoParaProducto[];
    
    
    private int idInsumo[];
    private String nombre[];
    private int cantidad[];
    private int cantMin[];
    private int cantMax[];
    private double costo[];
    private String descripcion[];
    private String dir[];
    private int tamArreglo;
    
    //PARTE PRODUCTOS    
    private Producto productos[];
    private String nombreP[];
    private double precioP[];
    private String descripcionP[];
    private String dirP[];
    private int tamArregloP;
    
    
    
    public Inventario(Inventario inventario,String path){//constructor carga insumos
        
        
        recogerInsumosXml(path);// con esto se llena memoria de insumos[] y se define desde el xml
        
        for(int i=0;i<insumos.length;i++){
            System.out.println(insumos[i].toString());
        }
        tamArreglo=insumos.length+1;
        System.out.println(insumos[1].toString());
        
    }
    
    public Inventario(String path,Inventario inventario){//constructor carga productos
        
        int entr=inventario.tamArreglo;
        insumos = new Insumo[entr];
        insumos=inventario.insumos;
        
        
        recogerProductosXml(path);// con esto se llena memoria de prodctos[] y se define desde el xml
        
        Insumo vectorInsumoInterno[];
        Insumo vectorInsumoEnviar[];        
        for(int i=0;i<tamArregloP;i++){
            vectorInsumoInterno = new Insumo[productos[i].getInsumo().length];
            vectorInsumoEnviar= new Insumo[productos[i].getInsumo().length];
            vectorInsumoInterno=productos[i].getInsumo();
            int id;
            for(int j=0;j<vectorInsumoInterno.length;j++){
                    
                id=vectorInsumoInterno[j].getNumIdentificadorInsumo();
                for(int h=0;h<tamArreglo;h++){
                    if(id==insumos[h].getNumIdentificadorInsumo()){
                        
                        vectorInsumoEnviar[j]=insumos[h];
                        
                    }
                }
            }productos[i].setInsumo(vectorInsumoEnviar);
            
        }///insumos refrenciados con campos llenos en sus productos
        
        System.out.println("holix");
        
    }
    
    
    public Inventario(int ident,String nombre,int cant, int min, int max, double costo, String desc, String dirI,int verInv){

        insumos = new Insumo[1];
        insumos[0] = new Insumo(ident,nombre,cant,min,max,costo,desc,dirI);
        tamArreglo=insumos.length+1;
        System.out.println(insumos[0].toString());

    }
    
    public Inventario(int ident,String nombre,int cant, int min, int max, double costo, String desc, String dirI,int verInv, Inventario inventarioParam){
        
        int temp=inventarioParam.insumos.length;
        insumosInventarioAgregado = new Insumo[temp];
        insumosInventarioAgregado = inventarioParam.insumos;
        insumos= new Insumo[temp+1];
        
        for(int i=0;i<temp;i++){
            insumos[i]=insumosInventarioAgregado[i];
                    
        }
               
        insumos[temp]=new Insumo(ident,nombre,cant,min,max,costo,desc,dirI);
        
        for(int i=0;i<=temp;i++){
            System.out.println(insumos[i].toString());
        }
        tamArreglo=insumos.length+1;
        

    }
    
    
    
    public Inventario(int tam){
            
        insumos=new Insumo[tam];
        tamArreglo=insumos.length+1;
        
    }
    
    public Inventario(){
    this(0);
   
    }
    
           
   
    public void recogerInsumosXml(String path){
        
        
        try {
        File inputFile = new File(path);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(inputFile);
        doc.getDocumentElement().normalize();
        NodeList nList = doc.getElementsByTagName("insumo");
        
        tamArreglo=nList.getLength();
        
        insumos = new Insumo[nList.getLength()];
        idInsumo = new int[nList.getLength()];
        nombre= new String[nList.getLength()];
        cantidad= new int[nList.getLength()];
        cantMin= new int[nList.getLength()];
        cantMax= new int[nList.getLength()];
        costo= new double[nList.getLength()];
        descripcion=new String[nList.getLength()];
        dir=new String[nList.getLength()];
                
        for (int i = 0; i < nList.getLength(); i++) {
            Node nNode = nList.item(i);
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                idInsumo[i]=i+1;
                nombre[i]=eElement.getElementsByTagName("nombre").item(0).getTextContent();
                cantidad[i]=Integer.parseInt(eElement.getElementsByTagName("cantidad").item(0).getTextContent());
                cantMin[i]=Integer.parseInt(eElement.getElementsByTagName("minimo").item(0).getTextContent());
                cantMax[i]=Integer.parseInt(eElement.getElementsByTagName("maximo").item(0).getTextContent());
                costo[i]=Double.parseDouble(eElement.getElementsByTagName("costo").item(0).getTextContent());
                descripcion[i]=eElement.getElementsByTagName("descripcion").item(0).getTextContent();
                dir[i]=eElement.getElementsByTagName("imagen").item(0).getTextContent();
            
            }
         }
        
      } catch (Exception e) {
            System.out.println("no sirvio"); 
      }
        
        for (int i=0;i<tamArreglo;i++){
            insumos[i]=new Insumo(idInsumo[i],nombre[i],cantidad[i],cantMin[i],cantMax[i],costo[i],descripcion[i],dir[i]);
            
       
        }
        
    }


    public void recogerProductosXml(String path){
        
        try{
            
            File inputFile; 
            DocumentBuilderFactory dbFactory;
            DocumentBuilder dBuilder;
            Document doc;
            NodeList nProList;
            
            
            inputFile = new File(path);
            dbFactory = DocumentBuilderFactory.newInstance();
            dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();        
            nProList = doc.getElementsByTagName("producto");
        
        
            tamArregloP=nProList.getLength();        
            productos = new Producto[nProList.getLength()];
            nombreP= new String[nProList.getLength()];
            precioP= new double[nProList.getLength()];
            descripcionP=new String[nProList.getLength()];
            dirP=new String[nProList.getLength()];
            
            
            for (int i = 0; i < tamArregloP; i++) {
                Node nNode = nProList.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {                
                    Element eElement = (Element) nNode;                
                    nombreP[i]=eElement.getAttribute("nombre");
                    
                    precioP[i]=Double.parseDouble(eElement.getAttribute("precio"));
                    
                    descripcionP[i]=eElement.getAttribute("descripcion");
                    
                    dirP[i]=eElement.getAttribute("imagen");
                    

                    String tmp = new String( "" );

                    for(int j=1;j<eElement.getChildNodes().getLength();j=j+2){
                        tmp+= eElement.getChildNodes().item(j).getAttributes().item(0).getTextContent() + ",";
                        
                    }
                    

                    productos[i] = new Producto(nombreP[i],precioP[i],descripcionP[i],tmp,dirP[i]);
                    System.out.println(productos[i].toString());

                    }
                }
        }catch (Exception e) {
            System.out.println(e); 
        }    
            
        
                
      
    }

    public Double getCapital() {
        return capital;
    }

    public void setCapital(Double capital) {
        this.capital = capital;
    }

    public Insumo[] getInsumos() {
        return insumos;
    }

    public void setInsumos(Insumo[] insumos) {
        this.insumos = insumos;
    }

    public String[] getNombre() {
        return nombre;
    }

    public void setNombre(String[] nombre) {
        this.nombre = nombre;
    }

    public int[] getCantidad() {
        return cantidad;
    }

    public void setCantidad(int[] cantidad) {
        this.cantidad = cantidad;
    }

    public int[] getCantMin() {
        return cantMin;
    }

    public void setCantMin(int[] cantMin) {
        this.cantMin = cantMin;
    }

    public int[] getCantMax() {
        return cantMax;
    }

    public void setCantMax(int[] cantMax) {
        this.cantMax = cantMax;
    }

    public double[] getCosto() {
        return costo;
    }

    public void setCosto(double[] costo) {
        this.costo = costo;
    }

    public String[] getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String[] descripcion) {
        this.descripcion = descripcion;
    }

    public String[] getDir() {
        return dir;
    }

    public void setDir(String[] dir) {
        this.dir = dir;
    }

    public int getTamArreglo() {
        return tamArreglo;
    }

    public void setTamArreglo(int tamArreglo) {
        this.tamArreglo = tamArreglo;
    }

    public Producto[] getProductos() {
        return productos;
    }

    public void setProductos(Producto[] productos) {
        this.productos = productos;
    }

    public String[] getNombreP() {
        return nombreP;
    }

    public void setNombreP(String[] nombreP) {
        this.nombreP = nombreP;
    }

    public double[] getPrecioP() {
        return precioP;
    }

    public void setPrecioP(double[] precioP) {
        this.precioP = precioP;
    }

    public String[] getDescripcionP() {
        return descripcionP;
    }

    public void setDescripcionP(String[] descripcionP) {
        this.descripcionP = descripcionP;
    }

    public String[] getDirP() {
        return dirP;
    }

    public void setDirP(String[] dirP) {
        this.dirP = dirP;
    }

    public int getTamArregloP() {
        return tamArregloP;
    }

    public void setTamArregloP(int tamArregloP) {
        this.tamArregloP = tamArregloP;
    }
    
    
    
}

