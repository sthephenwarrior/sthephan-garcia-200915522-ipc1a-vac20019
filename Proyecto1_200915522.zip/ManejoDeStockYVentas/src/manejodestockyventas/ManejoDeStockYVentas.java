package manejodestockyventas;
import Ventanas.VentanaInicio;
/**
 * @author STHEPHAN ALEXANDER GARCIA MAROOQUIN
 * CARNET:200915522
 * IPC1 "A" VACACIONES 2019
 */
public class ManejoDeStockYVentas {
    
    public static void main(String[] args){
        VentanaInicio ventana1 = new VentanaInicio();
        ventana1.setVisible(true);
        
    }
}
