package practica1;

import java.util.Random;

/**
 * @author Sthephan Alexander Garcia Marooquin 200915522 IPC1AVACAS2019
 **/
public class TurnoEjecutando {
    
    private int turno, avion, escritorio, filaEscritorio, estacion, filaEstacion;
    
    private Turno []turnop;
    private Avion []avionp;  
    private Escritorio[][] escritoriop;
    private Estacion[][] estacionp;
    private Pasajero[] pasajerop;

    public TurnoEjecutando(int turno, int avion, int escritorio, int filaEscritorio, int estacion, int filaEstacion) {
        setTurno(turno);
        setAvion(avion);
        setEscritorio(escritorio);
        setFilaEscritorio(filaEscritorio);
        setEstacion(estacion);
        setFilaEstacion(filaEstacion);        
    }
    
    public void setTurno( int trn){
        this.turno =trn;    
    }
    
    public void setAvion(int avn){
        this.avion =avn;        
    }
    
    public void setEscritorio(int escrtr){      
       this.escritorio=escrtr;      
    
    }
    
    public void setFilaEscritorio(int filaEscrtr){
        this.filaEscritorio=filaEscrtr;
    
    }

    public void setEstacion(int estscn){
        this.estacion=estscn;
    }
    
    public void setFilaEstacion( int filaStacn){
        this.filaEstacion=filaStacn;
    }
    
    public int getTurno(){
        return turno;
    }
    
    public int getAvion(){
        return avion;
    }
    
    public int getEscritorio(){
        return escritorio;
    }
    
    public int getFilaEscritorio(){
        return filaEscritorio;
    }
    
    public int getEstacion(){
        return estacion;
    }
    
    public int getFilaEstacion(){
        return filaEstacion;
    }
    
    public String toString(){
        
        return  "*************************************************************\n"
                +"*Se simularan: \n*"+ turno+"* turnos de arribo de la simulación.\n*"+avion+"* Aviones.\n"
                +"*"+escritorio+"* Escritorios con: *"+filaEscritorio+"* turnos en cola.\n*"
                +estacion+"* Estaciones de servicio de Aviones con: *"+filaEstacion+"* turnos en cola\n*de aviones arribados.\n"
                +"*presione Continuar, para efectuar la simulacion paso a paso, hasta que le\n*indique que terminó la simulación. "
                +"Presione abortar si desea interrumpir\n la simulación.\n"
                +"*************************************************************\n";
    
    }
}

class Turno{
    
    private int turnito;

public Turno(int ent){
    setTurnito(ent);
    
}    
    
    public Turno(){
    }

    public void setTurnito(int turnito) {
        this.turnito = turnito;
    }

    public int getTurnito() {
        return turnito;
    }
    
    public int valoTipoAvionint(){
        Random val = new Random();
        int valPro= 1+val.nextInt(100);
        return valPro;
    }

     public String toConsola(){
         int n=turnito+1;
        return"*****TURNO "+n+" *****\n";
    }
   
}

class Avion{
    
    private String tipo;
    private int numAvion;
    private int pasaj;

    public Avion(String tipoAv, int a){
        setAvion(tipoAv);
        setNumAvion(a);
        randomCantpasajero();
        
    
    }

    public int getPasaj() {
        return pasaj;
    }

    public void setPasaj(int pasaj) {
        this.pasaj = pasaj;
    }
    
    public Avion(){
    }
    
    public void setAvion(String tpAvRecep){
        this.tipo= tpAvRecep;
    }

    public int getNumAvion() {
        return numAvion;
    }

    public void setNumAvion(int numAvion) {
        this.numAvion = numAvion;
    }
    
    public int randomCantpasajero(){
        
        Random val = new Random();

        if(tipo.equals("pequeño")){
            pasaj= 5+val.nextInt(6);
        }else
        if(tipo.equals("mediano")){            
            pasaj= 15+val.nextInt(11);
        }else
        if(tipo.equals("grande")){            
            pasaj= 30+val.nextInt(11);
        } return pasaj;
    }
    
     public String toConsola(){
         int n=numAvion+1;
        return
              "Arribando Avión: "+n+" "+tipo+" con "+ pasaj+" pasajeros\n";
    }
    
}
class Pasajero{
    
    private int maletas;
    private int documentos;
    
    public Pasajero(){
    }



}

class Escritorio{
    private int cantidadEscritorios;
    private int filEscritorios;
    
    public Escritorio(int escri, int filaEsctr){
        this.cantidadEscritorios = escri;
        this.filEscritorios= filaEsctr;
    
    }
    
    public Escritorio(){
    
    
    }

}

class Estacion{
    private int cantidadEstaciones;
    private int filaEstacion;
    
    public Estacion(int esta, int flesctr){
        this.cantidadEstaciones= esta;
        this.filaEstacion= flesctr;
                

    }
    
    public Estacion(){
    
    }
    

}
/*
public TurnoEjecutando(Turno[] t, Avion[] a, Escritorio[][] e, Estacion[][] s, Pasajero[] p){
        setvectorTurno(t);
        setvectorAvion(a);
        setMatrizEscritorio(e);
        setMatrizServicio(s);
        setVectorPasajero(p);
    
    }
    

    
    public void setvectorTurno(Turno[] t){
        this.turnop = t;
    
    }
    
    public void setvectorAvion(Avion[] a){
        this.avionp = a;
    
    }
    
    public void setMatrizEscritorio(Escritorio[][] e){
        this.escritoriop = e;
    
    }
    
    public void setMatrizServicio(Estacion[][] s){
        this.estacionp=s;
    }
    
    public void setVectorPasajero(Pasajero[] p){
        this.pasajerop=p;
    }
    
    public Turno[] getVectorTurno(){
        return turnop;
    }
    
    public Avion[] getVectorAvion(){
        return avionp;
    }
    
    public Escritorio[][] getMatrizEscritorio(){
        return escritoriop;
    }
    
    public Estacion[][] getMatrizEstacion(){
        return estacionp;
    }
    
    
    public Pasajero[] getVectorPasajero(){
        return pasajerop;
    }
    
    
    
*/