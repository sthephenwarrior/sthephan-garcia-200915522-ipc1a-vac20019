package practica1;
/**
 * @author Sthephan Alexander Garcia Marooquin 200915522 IPC1AVACAS2019
 **/

public class PantallaInicial extends javax.swing.JFrame {
    
    private int a,b,c,d,e,f;
    
    private TurnoEjecutando llamadorTurno;
    
    private Turno []turnop;
    private Avion []avionp;  
    private Escritorio[][] escritoriop;
    private Estacion[][] estacionp;
    private Pasajero[] pasajerop;
    private int contadorA;
    private int contadorB;
    

    public PantallaInicial() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cantidadTurno = new javax.swing.JTextField();
        cantidadAvion = new javax.swing.JTextField();
        cantidadEscritorio = new javax.swing.JTextField();
        cantidadFilaEscritorio = new javax.swing.JTextField();
        cantidadServicio = new javax.swing.JTextField();
        cantidadFilaServicio = new javax.swing.JTextField();
        iniciarSimulacion = new javax.swing.JButton();
        pasoSimulacion = new javax.swing.JButton();
        finalizarSimulacion = new javax.swing.JButton();
        abortarSimulacion = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        consola = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("IPC1 A vacaciones 2019");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Simulación Aeropuerto");

        jLabel2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel2.setText("Cantidad de turnos:");

        jLabel3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel3.setText("Cantidad de aviones:");

        jLabel4.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel4.setText("Numero de escritorios");

        jLabel5.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel5.setText("Tamaño de la fila de registro");

        jLabel6.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel6.setText("Numero de estaciones de servicio");

        jLabel7.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel7.setText("Tamaño de fila de estaciones de servicio");

        cantidadAvion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cantidadAvionActionPerformed(evt);
            }
        });

        cantidadEscritorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cantidadEscritorioActionPerformed(evt);
            }
        });

        cantidadFilaEscritorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cantidadFilaEscritorioActionPerformed(evt);
            }
        });

        cantidadServicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cantidadServicioActionPerformed(evt);
            }
        });

        cantidadFilaServicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cantidadFilaServicioActionPerformed(evt);
            }
        });

        iniciarSimulacion.setText("Comenzar simulación");
        iniciarSimulacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniciarSimulacionActionPerformed(evt);
            }
        });

        pasoSimulacion.setText("Continuar>>>");
        pasoSimulacion.setEnabled(false);
        pasoSimulacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasoSimulacionActionPerformed(evt);
            }
        });

        finalizarSimulacion.setText("Salir");
        finalizarSimulacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finalizarSimulacionActionPerformed(evt);
            }
        });

        abortarSimulacion.setText("AbortarX");
        abortarSimulacion.setEnabled(false);
        abortarSimulacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abortarSimulacionActionPerformed(evt);
            }
        });

        consola.setBackground(new java.awt.Color(0, 0, 153));
        consola.setColumns(20);
        consola.setFont(new java.awt.Font("Monospaced", 1, 14)); // NOI18N
        consola.setForeground(new java.awt.Color(255, 255, 0));
        consola.setRows(5);
        consola.setText("\t\t**Simulación aeropuerto**\n******************\nTurno:_ de simulación\nArribo de avión:_\nDesabordaje de avión:_\n******************\nArea de registro de pasajeros\n******************\nArea de mantenimiento de aeronaves\n******************\nFin turno:_\nTurnos restantes:_\n******************");
        jScrollPane1.setViewportView(consola);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(52, 52, 52)
                                .addComponent(iniciarSimulacion, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(pasoSimulacion, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(abortarSimulacion, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(finalizarSimulacion, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(68, 68, 68)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(128, 128, 128))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(100, 100, 100))
                                            .addComponent(jLabel7))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(cantidadTurno, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(cantidadAvion, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(cantidadEscritorio, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(cantidadFilaServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(cantidadFilaEscritorio, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(cantidadServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 487, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 29, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cantidadTurno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cantidadAvion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cantidadEscritorio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cantidadFilaEscritorio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cantidadServicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cantidadFilaServicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(iniciarSimulacion, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(finalizarSimulacion, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pasoSimulacion)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(abortarSimulacion)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cantidadEscritorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cantidadEscritorioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cantidadEscritorioActionPerformed

    private void cantidadFilaEscritorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cantidadFilaEscritorioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cantidadFilaEscritorioActionPerformed

    private void cantidadServicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cantidadServicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cantidadServicioActionPerformed

    private void cantidadFilaServicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cantidadFilaServicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cantidadFilaServicioActionPerformed

    private void cantidadAvionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cantidadAvionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cantidadAvionActionPerformed

    private void iniciarSimulacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniciarSimulacionActionPerformed
        try{
        recogerDatosDeJTextArea();
        pasoSimulacion.setEnabled(true);
        abortarSimulacion.setEnabled(true);
        finalizarSimulacion.setEnabled(false);
        iniciarSimulacion.setEnabled(false);
        cantidadTurno.setEditable(false);
        cantidadAvion.setEditable(false);
        cantidadEscritorio.setEditable(false);
        cantidadFilaEscritorio.setEditable(false);
        cantidadServicio.setEditable(false);
        cantidadFilaServicio.setEditable(false);
        }catch(Exception e){            
           (new Warning(this,true)).setVisible(true);            
        }
    }//GEN-LAST:event_iniciarSimulacionActionPerformed
    private void recogerDatosDeJTextArea(){
        a= Integer.parseInt(cantidadTurno.getText());
        b= Integer.parseInt(cantidadAvion.getText());
        c= Integer.parseInt(cantidadEscritorio.getText());
        d= Integer.parseInt(cantidadFilaEscritorio.getText());
        e= Integer.parseInt(cantidadServicio.getText());
        f= Integer.parseInt(cantidadFilaServicio.getText());        
        llamadorTurno = new TurnoEjecutando(a,b,c,d,e,f);        
        String conv = llamadorTurno.toString();        
        consola.setText(conv);
        contadorA=0;
        contadorB=0;
        
        turnop = new Turno[a];
        for(int i=0;i<a;i++){            
            turnop[i] = new Turno();            
        }
        
        avionp = new Avion[b];
        for(int i=0;i<b;i++){            
            avionp[i] = new Avion();            
        }
        
        escritoriop = new Escritorio[c][d];
        for(int i=0;i<c;i++){
            for(int j=0;j<d;j++){
                escritoriop[i][j]=new Escritorio();            
            }
        
        }
        
        estacionp = new Estacion[e][f];
        for(int i=0;i<e;i++){
            for(int j=0;j<f;j++){
                estacionp[i][j]=new Estacion();            
            }        
        }
    }
        
    private void pasoSimulacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasoSimulacionActionPerformed
        pasoAPaso();        
    }//GEN-LAST:event_pasoSimulacionActionPerformed

    private void pasoAPaso(){

        String tipoAvion="";
        turnop[contadorA]= new Turno(contadorA);
        int prob=turnop[contadorA].valoTipoAvionint();
            
        if(prob>0&&prob<26){
            tipoAvion="pequeño";
        }else
        if(prob>25&&prob<56){
            tipoAvion="mediano";
        }else
        if(prob>55&&prob<101){
            tipoAvion="grande";
        }

        if(contadorA<(a-1)){
            
            String conv1 =turnop[contadorA].toConsola();
            consola.append(conv1);
            
            /*llamadorTurno = new TurnoEjecutando(turnop,avionp,escritoriop,estacionp,pasajerop);
            String conv =llamadorTurno.toConsola();
            consola.append(conv);*/
            
            if(contadorB<=(b-1)){
            if(contadorB<=(b-1)){
            avionp[contadorB] = new Avion(tipoAvion,contadorB);
            String conv2 =avionp[contadorB].toConsola();
            
            consola.append(conv2);
            pasajerop = new Pasajero[avionp[contadorB].randomCantpasajero()];
                        
            }else{
                
                contadorB=contadorB-1;
                avionp[contadorB] = new Avion(tipoAvion,contadorB);
                String conv2 =avionp[contadorB].toConsola();
                consola.append(conv2);
                
            
            }
            contadorB++;}
            
        }else{
            String conv1 =turnop[contadorA].toConsola();
            consola.append(conv1);
            consola.append("Se finalizaron los turnos de la simulación, que tenga buen dia.");
            pasoSimulacion.setEnabled(false);
            abortarSimulacion.setEnabled(false);
            finalizarSimulacion.setEnabled(true);
            iniciarSimulacion.setEnabled(true);
            cantidadTurno.setEditable(true);
            cantidadAvion.setEditable(true);
            cantidadEscritorio.setEditable(true);
            cantidadFilaEscritorio.setEditable(true);
            cantidadServicio.setEditable(true);
            cantidadFilaServicio.setEditable(true);
            contadorA=0;
        }
        
        contadorA++;
        
        
        
        
            
       
    }
    
    private void pasajeros(String reci){
        
        

        
    
    }
    
    private void pasoATurno(Avion obj){
        
        
        
        
        
        
    
    }
    
    private void abortarSimulacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abortarSimulacionActionPerformed
        consola.append("Se aborto la simulación...");
        pasoSimulacion.setEnabled(false);
        abortarSimulacion.setEnabled(false);
        finalizarSimulacion.setEnabled(true);
        iniciarSimulacion.setEnabled(true);
        cantidadTurno.setEditable(true);
        cantidadAvion.setEditable(true);
        cantidadEscritorio.setEditable(true);
        cantidadFilaEscritorio.setEditable(true);
        cantidadServicio.setEditable(true);
        cantidadFilaServicio.setEditable(true);
        contadorA=0;
    }//GEN-LAST:event_abortarSimulacionActionPerformed

    private void finalizarSimulacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finalizarSimulacionActionPerformed
        dispose();
    }//GEN-LAST:event_finalizarSimulacionActionPerformed
          
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PantallaInicial().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton abortarSimulacion;
    private javax.swing.JTextField cantidadAvion;
    private javax.swing.JTextField cantidadEscritorio;
    private javax.swing.JTextField cantidadFilaEscritorio;
    private javax.swing.JTextField cantidadFilaServicio;
    private javax.swing.JTextField cantidadServicio;
    private javax.swing.JTextField cantidadTurno;
    private javax.swing.JTextArea consola;
    private javax.swing.JButton finalizarSimulacion;
    private javax.swing.JButton iniciarSimulacion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton pasoSimulacion;
    // End of variables declaration//GEN-END:variables
}
