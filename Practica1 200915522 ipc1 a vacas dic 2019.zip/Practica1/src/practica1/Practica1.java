package practica1;

/**
 * @author Sthephan Alexander Garcia Marooquin 200915522 IPC1AVACAS2019
 **/
public class Practica1 {
        
    public static void main(String[] args) {
        PantallaInicial a=new PantallaInicial();
        a.setVisible(true);
        
    }    
}

