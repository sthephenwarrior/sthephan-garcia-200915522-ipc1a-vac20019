package agenda.colabrs;

public class NodoCol {
    public Colaborador objeto;
    public NodoCol siguiente;
    public NodoCol anteror;
    
    public NodoCol(Colaborador referenciaObjeto){
        this(referenciaObjeto,null,null);
    
    }
    
    public NodoCol(Colaborador referenciaObjeto, NodoCol sig, NodoCol ant){
        this.objeto=referenciaObjeto;
        this.siguiente=sig;
        this.anteror=ant;
    }
    public NodoCol(Colaborador referenciaObjeto, NodoCol sig){
        this.objeto=referenciaObjeto;
        this.siguiente=sig;
        
    }
    
}
