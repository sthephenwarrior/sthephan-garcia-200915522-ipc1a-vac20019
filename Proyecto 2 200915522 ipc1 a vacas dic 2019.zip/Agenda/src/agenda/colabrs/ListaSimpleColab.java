package agenda.colabrs;

public class ListaSimpleColab {
    
    private NodoCol cabeza;
    private NodoCol fin;
    
    public ListaSimpleColab(){
        cabeza=fin=null;    
    }
    
    public boolean estaVacia(){
        return null==cabeza;
    }
    
    public void insertarAlInicio(Colaborador objetoRef){
        
        if(estaVacia()){
            cabeza=fin= new NodoCol(objetoRef);
        }else{
            cabeza=new NodoCol(objetoRef,cabeza);
            fin=cabeza.siguiente;
            
        }
    }
    
    public void insertarAlFinal(Colaborador objetoRef){
            if(estaVacia()){
                cabeza=fin= new NodoCol(objetoRef);
            }else{
                fin.siguiente=new NodoCol(objetoRef,null);
                fin=fin.siguiente;
                    
            }
}
    
    public int tamanio(){
        int contador=0;
        if(!estaVacia()){
            NodoCol aux=cabeza;
            while(aux!=null){
                contador++;
                aux=aux.siguiente;
            }
        return contador;    
        }return contador;
    }
    
    public void eliminarNodo(){
    }
    
    public Colaborador obtenerTodos(int indice){
        
        if(!estaVacia()){
            Colaborador colabr;
            int ind =indice;
            int cont=0;
            NodoCol aux=cabeza;
            colabr=new Colaborador();
            while(cont<ind){
                aux=aux.siguiente;
                cont++;
            }
            colabr=aux.objeto;
            return colabr;
        }else{Colaborador colabr=new Colaborador();return colabr;}
    }
    
    
    public void imprimir(){
        NodoCol nodoAuxiliar = this.cabeza;
        int contador;
        if(nodoAuxiliar!=null){
            if(nodoAuxiliar.siguiente!=null){
                contador=1;
                do{ 
		    System.out.println("posicion: "+contador+" objeto: "+nodoAuxiliar.objeto.toString());           
		    if(nodoAuxiliar!=null){                    
			nodoAuxiliar = nodoAuxiliar.siguiente;
                    	contador++;                
		    }
                }while(nodoAuxiliar!=null);            
            }else{
		contador=1;
		System.out.println("posicion: "+contador+" objeto: "+nodoAuxiliar.objeto.toString());
                
            }            
        }else{
		System.out.println("esta Vacia");
	}
    }
    
}
