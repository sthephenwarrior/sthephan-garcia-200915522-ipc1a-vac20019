package agenda.colabrs;
public class Colaborador{
    private String nombre;
    private String nick;
    private String rol;
    private String telefono;
    
    
    public Colaborador(){
        this("","","","");
    }
    
    public Colaborador(String name, String nik,String rol,String tel){
        setNombre(name);
        setNick(nik);
        setRol(rol);
        setTelefono(tel);        
    
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    
    public String[] obtenerAtributos() {
        String[] vector;
        vector =new String[4];
        vector[0]=nombre;
        vector[1]=nick;
        vector[2]=rol;
        vector[3]=telefono;
        return vector;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", nick: " + nick + ", rol: " + rol + ", telefono: " + telefono;
    }
    
    
}
