package agenda;
import agenda.colabrs.ListaDoble;
import agenda.colabrs.Colaborador;
import agenda.colabrs.ListaSimpleColab;
import agenda.tablers.ListaCircularSimple;
import agenda.tablers.Tablero;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
/**
 * @author Sthephan Alexander Garcia Marroquin IPC1 A VACACIONES DIC 2019
 */
public class Agenda{
    
    JButton[] colaboradoresDeTablero;
    
    private JFrame pantallaInicial;
    private JLabel bienvenida;
    private JLabel bienvenida2;
    private JButton crearTablero;
    private JButton manejarTablero;
    private JButton crearColaboradores;
    private JButton manejarColaboradores;
    
    private JFrame manejadorDeTableros;
    
    private ListaDoble listaColaboradores;
    
    private ListaCircularSimple listaCircSimpTableros;
    private Tablero objetoTablerosDeAg;
    private Tablero vectorTableros[];
    
    private ListaSimpleColab listaSIMPColabEnMemoParaTabls;
    
    public Agenda(){
        
        construirJframe();
        aniadirActionListener();
        listaColaboradores = new ListaDoble();
        listaCircSimpTableros = new ListaCircularSimple();
        listaSIMPColabEnMemoParaTabls=new ListaSimpleColab();
        int verf=listaColaboradores.tamanio();
        int verf2=listaCircSimpTableros.tamanio();
        if(verf==0){
            manejarColaboradores.setEnabled(false);
        }
        if(verf2==0){
            manejarTablero.setEnabled(false);
        }
    }

    public static void main(String[] args) {
        
        Agenda objeto = new Agenda();
        
    }
    
    public void construirJframe(){
        
        bienvenida = new JLabel("<html><body><h1>Bienvenido a agenda</h1></body></html>");
        bienvenida2 = new JLabel("<html><body><h2>Gestione diferentes actividades con los tableros y dentro de ellos tareas con sus notas.</h2></body></html>");
        
        crearTablero = new JButton("Crear Tablero");
        manejarTablero = new JButton("Manejar tableros");
        crearColaboradores = new JButton("Crear Colaboradores");
        manejarColaboradores = new JButton("Manejar Colaboradores");
        
        pantallaInicial = new JFrame();
        pantallaInicial.setVisible(true);
        pantallaInicial.setBounds(100,100,600, 600);
        pantallaInicial.setLocationRelativeTo(null);
        pantallaInicial.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pantallaInicial.setTitle("Agenda");
        pantallaInicial.setLayout(null);
        pantallaInicial.getContentPane().setBackground(Color.CYAN);
        pantallaInicial.setResizable(false);
        
        bienvenida.setBounds(167,15,246,35);
        bienvenida2.setBounds(15,55,550,70);
        
        crearTablero.setBounds(25,175,242,125);
        crearColaboradores.setBounds(312,175,242,125);
        manejarTablero.setBounds(25,382,242,125); 
        manejarColaboradores.setBounds(312,382,242,125);
        
        crearTablero.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        crearTablero.setFont(new Font("Comic Sans MS", Font.BOLD,24));
        crearColaboradores.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        crearColaboradores.setFont(new Font("Comic Sans MS", Font.BOLD,20));
        manejarTablero.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        manejarTablero.setFont(new Font("Comic Sans MS", Font.BOLD,24));
        manejarColaboradores.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        manejarColaboradores.setFont(new Font("Comic Sans MS", Font.BOLD,20));
        
        pantallaInicial.getContentPane().add(bienvenida);
        pantallaInicial.getContentPane().add(bienvenida2);
        pantallaInicial.getContentPane().add(crearTablero);
        pantallaInicial.getContentPane().add(crearColaboradores);
        pantallaInicial.getContentPane().add(manejarTablero);
        pantallaInicial.getContentPane().add(manejarColaboradores);
        
    }
    
    public void aniadirActionListener(){
        
        crearTablero.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                crearTablero();
            }
        
        });
        crearColaboradores.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                crearColaborador();
            }
        
        });
    
    }
    
    public void anyadirColEnMemoATablerosAlist(int ind){
        
        //anyadirColEnMemoATablerosAlist
    
    
    }
    
    
    public void crearTablero(){
        JFrame p2 = new JFrame();
        
        p2.setResizable(false);
        p2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        p2.setLayout(null);
        
        p2.setBounds(0,0,750, 600);
        p2.setLocationRelativeTo(null);
        p2.setTitle("Crear Tablero");
        p2.getContentPane().setBackground(Color.GREEN);
        
        JTextField nombre = new JTextField();
        nombre.setBounds(45, 15, 645, 60);
        nombre.setBorder(BorderFactory.createTitledBorder(null, "Ingrese nombre del Tablero", TitledBorder.CENTER, TitledBorder.TOP));
        
        ButtonGroup buttonGroup = new ButtonGroup();
        
        JRadioButton btn01 = new JRadioButton("Publico");
        btn01.setBounds(75,90, 280, 75);
        btn01.setFont(new Font("Comic Sans MS", Font.BOLD,24));
        buttonGroup.add(btn01);
        
        JRadioButton btn02 = new JRadioButton("Privado");
        btn02.setBounds(380, 90,280, 75);
        btn02.setFont(new Font("Comic Sans MS", Font.BOLD,24));
        buttonGroup.add(btn02);
        
        String[] selColores = {"Rojo","Azul","Amarillo","Verde","Anaranjado"};
        JComboBox colores = new JComboBox(selColores);
        colores.setBounds(25,180,150,50);
        colores.setFont(new Font("Comic Sans MS", Font.BOLD,24));
        
        int cantColabsEnMemo =listaColaboradores.tamanio();
        if(cantColabsEnMemo>0){
            
            colaboradoresDeTablero= new JButton[cantColabsEnMemo];
            
            JScrollPane contenedor = new JScrollPane();
            contenedor.setBounds(180,170,520,270);
            
            JPanel elegirColaboradores = new JPanel();
            elegirColaboradores.setBorder(BorderFactory.createTitledBorder(null, "Colaboradores existentes", TitledBorder.CENTER, TitledBorder.TOP));
            elegirColaboradores.setPreferredSize(new Dimension(510,(15+(cantColabsEnMemo*30))));
            elegirColaboradores.setLayout(null);
            elegirColaboradores.setBackground(Color.CYAN);
            contenedor.setViewportView(elegirColaboradores);
            
            Colaborador[] colab= new Colaborador[cantColabsEnMemo];
            
            for(int a=0;a<cantColabsEnMemo;a++){
                
                colab[a]=listaColaboradores.obtenerTodos(a);
                Colaborador local = new Colaborador();
                local =colab[a];
                final Colaborador local2 = local;

                colaboradoresDeTablero[a] = new JButton(listaColaboradores.obtenerTodos(a).toString()); 
		colaboradoresDeTablero[a].setBounds(0,15+(a*30),500,30);
                colaboradoresDeTablero[a].setHorizontalAlignment(SwingConstants.LEFT);
                colaboradoresDeTablero[a].setEnabled(false);
                colaboradoresDeTablero[a].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(listaSIMPColabEnMemoParaTabls.estaVacia()){
                            listaSIMPColabEnMemoParaTabls.insertarAlFinal(local2);
                            
                            /*if ( e.getSource(). ==  ) {
                            ((JButton)ev.getSource).setEnabled( false );
                            }*/
                            
                            
                            listaSIMPColabEnMemoParaTabls.imprimir();
                        }else{
                            
                            int contAuxst=listaSIMPColabEnMemoParaTabls.tamanio();
                            Colaborador[] vectorColaboradores2;
                            vectorColaboradores2 = new Colaborador[contAuxst];
                            for(int d=0;d<contAuxst;d++){
                                Colaborador temp=new Colaborador();
                                temp=listaSIMPColabEnMemoParaTabls.obtenerTodos(d);
                                vectorColaboradores2[d]=temp;
                            }
                            boolean flag=true;
                            int point=0;
                            do{
                                flag=local2.getNick().equalsIgnoreCase(vectorColaboradores2[point].getNick());
                                point++;                            
                            }while(flag);//*/
                            if(flag){
                                JOptionPane.showMessageDialog(null, "¡ADVERTENCIA! el  Colaborador elegido ya ha sido ingresado al tablero, pruebe con otro.", "Colaborador Ya ingresado.", JOptionPane.WARNING_MESSAGE);
                            }else{
                                listaSIMPColabEnMemoParaTabls.insertarAlFinal(local2);
                                listaSIMPColabEnMemoParaTabls.imprimir();
                            }
                            
                            
                            
                            
                        //listaSIMPColabEnMemoParaTabls.insertarAlFinal(local2);
                        //listaSIMPColabEnMemoParaTabls.imprimir();
                        }
                    }
                });
                
		elegirColaboradores.add(colaboradoresDeTablero[a]);
            }
            
            btn02.addItemListener(new ItemListener(){
                @Override
                public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    for(int a=0;a<cantColabsEnMemo;a++){
                        colaboradoresDeTablero[a].setEnabled(true);
                        elegirColaboradores.add(colaboradoresDeTablero[a]);
                    }
                }
                else if (e.getStateChange() == ItemEvent.DESELECTED) {
                    for(int a=0;a<cantColabsEnMemo;a++){
                        colaboradoresDeTablero[a].setEnabled(false);
                        elegirColaboradores.add(colaboradoresDeTablero[a]);
                    }
                }
                }
            });
            
            p2.getContentPane().add(contenedor);
        }else{
            JScrollPane contenedor = new JScrollPane();
            contenedor.setBounds(180,170,520,270);
            JPanel elegirColaboradores = new JPanel();
            elegirColaboradores.setBorder(BorderFactory.createTitledBorder(null, "Colaboradores existentes(SIN COLABORADORES CREADOS AL MOMENTO)", TitledBorder.CENTER, TitledBorder.TOP));
            elegirColaboradores.setPreferredSize(new Dimension(510,(15+(cantColabsEnMemo*30))));
            elegirColaboradores.setLayout(null);
            elegirColaboradores.setBackground(Color.CYAN);
            contenedor.setViewportView(elegirColaboradores);
            p2.getContentPane().add(contenedor);
            
        }
    
        JButton crear = new JButton("Crear");
        crear.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        crear.setFont(new Font("Comic Sans MS", Font.BOLD,24));
        crear.setBounds(75,460,280, 75);
        crear.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                String nm;
                nm=nombre.getText();
		int opt= colores.getSelectedIndex();
                Color colorElec= new Color(0,0,0);
                switch(opt){
                    case 0:colorElec=Color.RED;
                    break;
                    case 1:colorElec=Color.BLUE;
                    break;
                    case 2:colorElec=Color.YELLOW;
                    break;
                    case 3:colorElec=Color.GREEN;
                    break;
                    case 4:colorElec=Color.ORANGE;
                    break;
                }
                
                boolean flag=true;
                
                if(nombre.getText().isEmpty()||buttonGroup.getSelection().equals(null)||opt==-1){
                    JOptionPane.showMessageDialog(null,"Todos los campos deben de estar rellenados para crear un Tablero","CrearTablero",JOptionPane.WARNING_MESSAGE);                    
                }else{
                    if(btn01.isSelected()){flag=true;}else{flag=false;}
                    if(listaCircSimpTableros.tamanio()>0){
                        int contAuxs=listaCircSimpTableros.tamanio();
                        Tablero[] vectorTableros2= new Tablero[contAuxs];
                        
                        
                        //CICLO OBTENER TODOS LOS TABLEROS
                        
                        //CICLO BUSCAR TABLEROS QUE EXISTAN
            
                        
                                JOptionPane.showMessageDialog(null, "¡ADVERTENCIA! el  \"Nombre\" ingresado para crear tablero ya existe, pruebe con otro.", "Nombre Ya existente.", JOptionPane.WARNING_MESSAGE);
                        
                                aniadirALaListaCircularDeTab(colorElec,nm,flag);
                                p2.setVisible(false);
                                pantallaInicial.setVisible(true);
                                            
                        
                    }else{
                        aniadirALaListaCircularDeTab(colorElec,nm,flag);
                        p2.setVisible(false);
                        pantallaInicial.setVisible(true);
                        manejarTablero.setEnabled(true); 
                    }
                }
            }
        });
        
        JButton cancelarTab = new JButton("Cancelar");
        cancelarTab.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        cancelarTab.setFont(new Font("Comic Sans MS", Font.BOLD,24));
        cancelarTab.setBounds(380,460, 280, 75);
        cancelarTab.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                int sel=JOptionPane.showConfirmDialog(null, "¿Está seguro que desea cancelar, la creación del tablero?", "¿Cancelar creación de tablero?", JOptionPane.YES_NO_OPTION);
                if(sel==JOptionPane.YES_OPTION){
                    p2.setVisible(false);
                    pantallaInicial.setVisible(true);                
                }
            }
        
        });
        
        p2.getContentPane().add(nombre);
        p2.getContentPane().add(btn01);
        p2.getContentPane().add(btn02);
        p2.getContentPane().add(colores);
        p2.getContentPane().add(crear);
        p2.getContentPane().add(cancelarTab);
        
        p2.setVisible(true);
        pantallaInicial.setVisible(false);
        
    }
    
    public void crearColaborador(){
        JFrame p1 = new JFrame();
        p1.setResizable(false);
        JTextField nombre = new JTextField();
        JTextField nick = new JTextField();
        JTextField rol = new JTextField();
        JTextField tel = new JTextField();
        
        JButton aceptar = new JButton("Aceptar");
        aceptar.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        aceptar.setFont(new Font("Comic Sans MS", Font.BOLD,24));
        aceptar.setBounds(25,350, 180, 75);
        aceptar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                String nm,nik,rOl,tEl;
                nm=nombre.getText();nik=nick.getText();rOl=rol.getText();tEl=tel.getText();
                if(nombre.getText().isEmpty()||nick.getText().isEmpty()||rol.getText().isEmpty()||tel.getText().isEmpty()){
                    JOptionPane.showMessageDialog(null,"Todos los campos deben de estar rellenados para crear un colaborador","Crear Colaboradore",JOptionPane.WARNING_MESSAGE);                    
                }else{                    
                    if(listaColaboradores.tamanio()>0){
                        int contAuxs=listaColaboradores.tamanio();
                        Colaborador[] vectorColaboradores;
                        vectorColaboradores = new Colaborador[contAuxs];
                        for(int c=0;c<contAuxs;c++){
                            Colaborador temp=new Colaborador();
                            temp=listaColaboradores.obtenerTodos(c);
                            vectorColaboradores[c]=temp;
                        }                        
                        boolean flag=true;
                        int point=0;
                        do{
                            flag=nik.equalsIgnoreCase(vectorColaboradores[point].getNick());
                            point++;                            
                        }while((point<contAuxs));
                        if(flag){
                                JOptionPane.showMessageDialog(null, "¡ADVERTENCIA! el  \"Nick\" ingresado ya existe, pruebe con otro.", "Nick Ya existente.", JOptionPane.WARNING_MESSAGE);
                        }else{
                            aniadirALaListaDobleDeColab(nm,nik,rOl,tEl);                                                    
                            p1.setVisible(false);
                            pantallaInicial.setVisible(true);
                        }
                    }else{
                        aniadirALaListaDobleDeColab(nm,nik,rOl,tEl); 
                        p1.setVisible(false);
                        pantallaInicial.setVisible(true);
                        manejarColaboradores.setEnabled(true);                                
                    }
                }
            }
        });
        
        JButton cancelar = new JButton("Cancelar");
        cancelar.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        cancelar.setFont(new Font("Comic Sans MS", Font.BOLD,24));
        cancelar.setBounds(225,350, 180, 75);
        cancelar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                int sel=JOptionPane.showConfirmDialog(null, "¿Está seguro que desea cancelar, la creación de colaborador?", "¿Cancelar creación de colaborador?", JOptionPane.YES_NO_OPTION);
                if(sel==JOptionPane.YES_OPTION){
                    p1.setVisible(false);
                    pantallaInicial.setVisible(true);                
                 }
            }        
        });
        
        nombre.setBounds(25, 15, 385, 60);
        nick.setBounds(25, 95, 385, 60);
        rol.setBounds(25, 175, 385, 60);
        tel.setBounds(25, 255, 385, 60);
        
        p1.setLayout(null);
        p1.setBounds(0, 0, 450, 500);
        p1.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        p1.setLocationRelativeTo(null);
        p1.setTitle("Agregando Colaborador");
        
        nombre.setBorder(BorderFactory.createTitledBorder(null, "Ingrese nombre del colaborador", TitledBorder.CENTER, TitledBorder.TOP));
        nick.setBorder(BorderFactory.createTitledBorder(null, "cree un \"Nick\" (identificador unico) del colaborador", TitledBorder.CENTER, TitledBorder.TOP));
        rol.setBorder(BorderFactory.createTitledBorder(null, "ingrese el rol del colaborador", TitledBorder.CENTER, TitledBorder.TOP));
        tel.setBorder(BorderFactory.createTitledBorder(null, "ingrese el telefono del colaborador", TitledBorder.CENTER, TitledBorder.TOP));
        
        p1.getContentPane().add(nombre);
        p1.getContentPane().add(nick);
        p1.getContentPane().add(rol);
        p1.getContentPane().add(tel);
        p1.getContentPane().add(aceptar);
        p1.getContentPane().add(cancelar);
        p1.setVisible(true);
        pantallaInicial.setVisible(false);
                
    }
    
    public void aniadirALaListaDobleDeColab(String nombreRef,String nickRef,String rolRef,String telRef){
        Colaborador colaboradores = new Colaborador(nombreRef,nickRef,rolRef,telRef);
        listaColaboradores.insertarAlFinal(colaboradores);
        int contAux=listaColaboradores.tamanio();
        if(contAux>1){
            Colaborador[] vectorColaboradores= new Colaborador[contAux];
            for(int c=0;c<contAux;c++){
                Colaborador temp=new Colaborador();
                temp=listaColaboradores.obtenerTodos(c);
                vectorColaboradores[c]=temp;
            }
            
            for(int i=0;i<(contAux-1);i++){
                for(int j=0;j<(contAux-1-i);j++){
                    if((vectorColaboradores[j].getNombre().compareTo(vectorColaboradores[j+1].getNombre()))>0){
                        Colaborador objetoColaboradorDeAg=vectorColaboradores[j];
                        vectorColaboradores[j]=vectorColaboradores[j+1];
                        vectorColaboradores[j+1]=objetoColaboradorDeAg;                        
                    }
                }
            }
            listaColaboradores=new ListaDoble();
            for(int i=0;i<contAux;i++){
                colaboradores = vectorColaboradores[i];
                listaColaboradores.insertarAlFinal(colaboradores);
            }
        
        }
        
        
    }
    
    public void aniadirALaListaCircularDeTab(Color colorRef,String nombreRef,boolean typeRef){
        Tablero tableros = new Tablero(colorRef,nombreRef,typeRef);
        listaCircSimpTableros.insertarAlFinal(tableros);
        listaCircSimpTableros.imprimir();
        
    }
    
    
}

