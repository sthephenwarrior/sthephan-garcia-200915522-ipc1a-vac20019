package agenda.tablers;

import agenda.colabrs.*;

public class NodoTab {
    private Tablero objeto;
    private NodoTab siguiente;
    private NodoTab anteror;
    
    public NodoTab(){
        this.objeto=null;
        this.siguiente=null;
        this.anteror=null;
    
    }
    
    public NodoTab(Tablero referenciaObjeto){
        this.objeto=referenciaObjeto;
        this.siguiente=null;
        this.anteror=null;
    }
    
    public NodoTab(Tablero referenciaObjeto, NodoTab sig, NodoTab ant){
        this.objeto=referenciaObjeto;
        this.siguiente=sig;
        this.anteror=ant;
        
    }
    
    public void setNodoSiguiente(NodoTab siguiente){
        this.siguiente=siguiente;
    
    }
    
    public void setNodoAnterior(NodoTab anterior){
        this.anteror= anterior;
    }
    
    public NodoTab getNodoSiguiente(){
        return this.siguiente;
    }
    
    public NodoTab getNodoAnterior(){
        return this.anteror;
    }
    
    public Tablero getObjeto(){
        return this.objeto;
    }
    
}
