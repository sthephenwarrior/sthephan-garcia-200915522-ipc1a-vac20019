package agenda.tablers;

import agenda.tablers.NodoTab;

public class ListaCircularSimple{
    
    private NodoTab cabeza;
    
    public ListaCircularSimple(){
        this.cabeza=null;
    
    }
    
    public boolean estaVacia(){
        return null==cabeza;
    }
    
    public void insertarAlFinal(Tablero objetoRef){
        NodoTab nuevo;
    
        if(estaVacia()){
            nuevo = new NodoTab(objetoRef);
            this.cabeza=nuevo;
            this.cabeza.setNodoSiguiente(this.cabeza);
        }
        else{
            NodoTab auxiliar = this.cabeza;
            
            while(auxiliar.getNodoSiguiente()!=this.cabeza){
                auxiliar = auxiliar.getNodoSiguiente();            
            }
            nuevo = new NodoTab(objetoRef);
            auxiliar.setNodoSiguiente(nuevo);
            nuevo.setNodoSiguiente(this.cabeza);
            
        
        }
        
    }
    
    public int tamanio(){
        if(!estaVacia()){
        NodoTab nodoAuxiliar = this.cabeza;
            int contador = 0;
            do{
                contador++;
                nodoAuxiliar = nodoAuxiliar.getNodoSiguiente();
                
            }while(nodoAuxiliar != this.cabeza);
            return contador;
        }return 0;
    }
    
    public void eliminarNodo(){
    }
    
    public Tablero obtenerTodos(){
        return null;
    }
    
    
    public void imprimir(){
        if(!estaVacia()){
            NodoTab nodoAuxiliar = this.cabeza;
            int contador = 0;
            do{                
                System.out.println("posicion: "+contador+" objeto: "+nodoAuxiliar.getObjeto().toString());
                nodoAuxiliar = nodoAuxiliar.getNodoSiguiente();
                contador++;
                
            }while(nodoAuxiliar!=this.cabeza);
        }
    }
    
}
