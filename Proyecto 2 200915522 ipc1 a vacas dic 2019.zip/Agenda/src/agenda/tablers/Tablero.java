package agenda.tablers;


import agenda.colabrs.Colaborador;
import java.awt.Color;

public class Tablero extends javax.swing.JPanel {
    
    private Color color;
    private String nombre;
    private boolean visibilidad;
    private Colaborador[] colaboradoresTab;
    private Colaborador idColaborador;
    
    public Tablero(){
        this(null,"",true);
    
    }
    

    public Tablero(Color refColor,String refNombre,boolean type) {
        setColor(refColor);
        setNombre(refNombre);
        setVisibilidad(type);
    }
    
    public void iniciarComponentes(){
        
        
    
    }

    public Colaborador[] getColaboradoresTab() {
        return colaboradoresTab;
    }

    public void setColaboradoresTab(Colaborador[] colaboradoresTab) {
        this.colaboradoresTab = colaboradoresTab;
    }

    public Colaborador getIdColaborador() {
        return idColaborador;
    }

    public void setIdColaborador(Colaborador idColaborador) {
        this.idColaborador = idColaborador;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isVisibilidad() {
        return visibilidad;
    }

    public void setVisibilidad(boolean visibilidad) {
        this.visibilidad = visibilidad;
    }

    @Override
    public String toString() {
        
        String visiv;
        if(visibilidad){
            visiv="Publico";
        }else{visiv="Privado";}
        
        return "Tablero{" + "color=" + color + ", nombre=" + nombre + ", visibilidad=" + visiv + '}';
    }
}